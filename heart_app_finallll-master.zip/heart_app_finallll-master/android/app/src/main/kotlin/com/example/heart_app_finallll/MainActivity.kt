package com.example.heart_app_finallll

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
