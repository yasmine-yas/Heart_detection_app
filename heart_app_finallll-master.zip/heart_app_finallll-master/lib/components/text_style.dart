import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

const TextStyle bntText = TextStyle(
  color: Colors.black,
  fontWeight: FontWeight.w500,
);